﻿
Partial Class Home
    Inherits System.Web.UI.Page

End Class
